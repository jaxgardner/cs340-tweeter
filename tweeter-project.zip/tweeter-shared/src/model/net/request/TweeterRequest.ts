export interface TweeterRequest {
  token: string;
}
