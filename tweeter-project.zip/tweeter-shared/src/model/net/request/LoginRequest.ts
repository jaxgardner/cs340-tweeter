export interface LoginRequest {
  alias: string;
  password: string;
}
