export interface UserDto {
  firstName: string;
  lastName: string;
  alias: string;
  imageUrl: string;
}
